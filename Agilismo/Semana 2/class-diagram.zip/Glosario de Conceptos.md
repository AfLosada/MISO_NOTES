
|Concepto|Descripción|Observaciones|
|---|---|---|
| Entrenador  | Es el usuario principal del sistema. Tiene un nombre, una contraseña y un correo para poder ingresar al sistema. | Encargado de crear ejercicios, crear clientes y añadirles entrenamientos a estos últimos. Cómo es el único usuario del sistema está encargado de mantener actualizada toda la información.  |
| Cliente  | Es aquel que es entrenado por un entrenador. Tiene nombre, apellidos, medidas, entrenamientos y reportes.  |   |
| Medidas  | Son las medidas de cada cliente. Talla, peso, edad, brazos, pecho, abdomen, cintura y piernas  | Se separan del cliente para desacoplar la información y evitar crear clases monolíticas.  |
| Entrenamiento | Es una colección de ejerciciosPorEntrenamiento. Tiene un inicio, un fin, y una razón del fin. |  |
| EjercicioPorEntrenamiento | Es una colección de ejericios que se dieron en un entrenamiento en **una fecha** dada. Incluye las repeticiones del ejericio y su duración. | Tiene la capacidad de calcular el consumo calórico |
| Ejercicio | Un ejericio (como jumping-jacks) que tiene un nombre, descripción, enlace y cantidad de calorias por repetición.  |  |
| Reporte | Un resumen de cada cliente, es único por cliente y tiene la información resumida del cliente. talla, peso, IMC, categoría IMC, consumo calórico y fecha. | Es importante entender que hay un reporte por fecha, que tiene sus ejerciciosPorEntrenamiento. |
